//
// Created by Charles-Eugene Loubao on 4/26/16.
//

#ifndef DRAGON_BALL_Z_RPG_EDITION_CHARACTERSTATES_H
#define DRAGON_BALL_Z_RPG_EDITION_CHARACTERSTATES_H

static const int STATE_DEAD = -1;
static const int STATE_IDLE = 0;
static const int STATE_BLOCKING = 1;

static const int STATE_KAIOKEN = 2;

#endif //DRAGON_BALL_Z_RPG_EDITION_CHARACTERSTATES_H
